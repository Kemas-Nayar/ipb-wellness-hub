import React, { useState } from 'react';
import { supabase } from '../supabase';
import iwhLogo from '../assets/logo_iwh.png';
import '../styles/AuthPage.css';

const EyeIcon = ({ open }) => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    {open ? (
      <>
        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
        <circle cx="12" cy="12" r="3"/>
      </>
    ) : (
      <>
        <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/>
        <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/>
        <line x1="1" y1="1" x2="23" y2="23"/>
      </>
    )}
  </svg>
);

const GoogleIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24">
    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
  </svg>
);

const Spinner = () => (
  <svg className="auth-spinner" width="18" height="18" viewBox="0 0 24 24"
    fill="none" stroke="currentColor" strokeWidth="2.5">
    <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" strokeLinecap="round"/>
  </svg>
);

const LoginPage = ({ onNavigate }) => {
  const [email,        setEmail]        = useState('');
  const [password,     setPassword]     = useState('');
  const [error,        setError]        = useState('');
  const [isLoading,    setIsLoading]    = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const validate = () => {
    if (!email.trim())    return 'Masukkan alamat email kamu';
    if (!/\S+@\S+\.\S+/.test(email)) return 'Format email tidak valid';
    if (!password)        return 'Masukkan password kamu';
    return null;
  };

  const handleLogin = async () => {
    const validationError = validate();
    if (validationError) { setError(validationError); return; }

    setIsLoading(true);
    setError('');

    try {
      const { error: loginError } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });

      if (loginError) {
        const msg = loginError.message.toLowerCase();
        if (msg.includes('invalid login credentials') || msg.includes('invalid credentials')) {
          setError('Email atau password salah.');
        } else if (msg.includes('email not confirmed')) {
          // Shouldn't happen if confirm email is OFF, but handle gracefully
          setError('Akun belum dikonfirmasi. Hubungi admin.');
        } else if (msg.includes('too many requests')) {
          setError('Terlalu banyak percobaan. Coba lagi nanti.');
        } else if (msg.includes('network') || msg.includes('fetch')) {
          setError('Koneksi gagal. Periksa internet kamu.');
        } else {
          setError(loginError.message);
        }
      }
      // On success: onAuthStateChange in App.jsx handles navigation
    } catch (err) {
      console.error('[Login] Unexpected error:', err);
      setError('Terjadi kesalahan. Coba lagi.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogle = async () => {
    setIsLoading(true);
    setError('');
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: { redirectTo: window.location.origin },
      });
      if (error) {
        setError('Login Google gagal: ' + error.message);
        setIsLoading(false);
      }
      // On success: browser redirects, App.jsx handles via URL parsing
    } catch (err) {
      console.error('[Login] Google error:', err);
      setError('Terjadi kesalahan pada Google login.');
      setIsLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-header">
        <button
          className="auth-back-btn"
          onClick={() => onNavigate('landing')}
          aria-label="Kembali ke beranda"
          disabled={isLoading}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M19 12H5M12 5l-7 7 7 7"/>
          </svg>
          Kembali
        </button>
        <img src={iwhLogo} alt="IPB Wellness Hub" className="auth-logo-iwh"/>
      </div>

      <div className="auth-body">
        <div className="auth-heading-group">
          <h1 className="auth-title">Welcome back,</h1>
          <p className="auth-subtitle">
            Senang melihatmu lagi! Masukkan email dan password untuk melanjutkan.
          </p>
        </div>

        {error && <p className="auth-error" role="alert">{error}</p>}

        <div className="auth-fields">
          <input
            className="auth-input"
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => { setEmail(e.target.value); setError(''); }}
            onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
            disabled={isLoading}
            autoComplete="email"
            autoFocus
          />
          <div className="auth-password-wrapper">
            <input
              className="auth-input"
              type={showPassword ? 'text' : 'password'}
              placeholder="Password"
              value={password}
              onChange={(e) => { setPassword(e.target.value); setError(''); }}
              onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
              disabled={isLoading}
              autoComplete="current-password"
            />
            <button
              type="button"
              className="auth-eye-btn"
              onClick={() => setShowPassword(p => !p)}
              aria-label={showPassword ? 'Sembunyikan password' : 'Tampilkan password'}
            >
              <EyeIcon open={showPassword}/>
            </button>
          </div>
        </div>

        <button className="btn-primary" onClick={handleLogin} disabled={isLoading}>
          {isLoading ? <><Spinner/> Memproses...</> : 'Log In'}
        </button>

        <p className="auth-forgot" onClick={() => !isLoading && onNavigate('forgot')}>
          Lupa password?
        </p>

        <div className="auth-divider"><span>atau</span></div>

        <button className="btn-google" onClick={handleGoogle} disabled={isLoading}>
          <GoogleIcon/>
          Lanjutkan dengan Google
        </button>

        <p className="auth-footer-text">
          Belum punya akun?{' '}
          <span className="auth-link" onClick={() => !isLoading && onNavigate('signup')}>
            Daftar sekarang
          </span>
        </p>
      </div>
    </div>
  );
};

export default LoginPage;